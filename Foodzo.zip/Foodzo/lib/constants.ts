export const FOODZO_USER_STORAGE_KEY = "foodzo_user";

export const PERMANENT_ADMIN_PHONE = "8979873681";
export const NORMALIZED_ADMIN_PHONE = PERMANENT_ADMIN_PHONE.replace(/[^0-9+]/g, "");
